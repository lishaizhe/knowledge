#include "ShaderCom.h"

void ShaderCom::init(CCNode* pNode, const char* vertex, const char* fragment)
{
	CCGLProgram* shader = new CCGLProgram();
	shader->initWithVertexShaderFilename(vertex, fragment);
	shader->addAttribute(kCCAttributeNamePosition, kCCVertexAttrib_Position);
	shader->addAttribute(kCCAttributeNameTexCoord, kCCVertexAttrib_TexCoords);
	shader->link();
	shader->updateUniforms();
	pNode->setShaderProgram(shader);
}

void ShaderCom::setOriginalShaderType(CCNode* pNode)
{
	pNode->setShaderProgram(CCShaderCache::sharedShaderCache()->programForKey(kCCShader_PositionTextureColor));
}