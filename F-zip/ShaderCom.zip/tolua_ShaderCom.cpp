/*
** Lua binding: ShaderCom
** Generated automatically by tolua++-1.0.92 on 09/01/14 02:01:04.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"
#include "ShaderCom.h"
#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_ShaderCom_open (lua_State* tolua_S);


/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"ShaderCom");
 tolua_usertype(tolua_S,"CCNode");
}

/* method: init of class  ShaderCom */
#ifndef TOLUA_DISABLE_tolua_ShaderCom_ShaderCom_init00
static int tolua_ShaderCom_ShaderCom_init00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"ShaderCom",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"CCNode",0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isstring(tolua_S,4,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,5,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CCNode* pNode = ((CCNode*)  tolua_tousertype(tolua_S,2,0));
  const char* vertex = ((const char*)  tolua_tostring(tolua_S,3,0));
  const char* fragment = ((const char*)  tolua_tostring(tolua_S,4,0));
  {
   ShaderCom::init(pNode,vertex,fragment);
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'init'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: setOriginalShaderType of class  ShaderCom */
#ifndef TOLUA_DISABLE_tolua_ShaderCom_ShaderCom_setOriginalShaderType00
static int tolua_ShaderCom_ShaderCom_setOriginalShaderType00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"ShaderCom",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"CCNode",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CCNode* pNode = ((CCNode*)  tolua_tousertype(tolua_S,2,0));
  {
   ShaderCom::setOriginalShaderType(pNode);
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'setOriginalShaderType'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_ShaderCom_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  tolua_cclass(tolua_S,"ShaderCom","ShaderCom","",NULL);
  tolua_beginmodule(tolua_S,"ShaderCom");
   tolua_function(tolua_S,"init",tolua_ShaderCom_ShaderCom_init00);
   tolua_function(tolua_S,"setOriginalShaderType",tolua_ShaderCom_ShaderCom_setOriginalShaderType00);
  tolua_endmodule(tolua_S);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_ShaderCom (lua_State* tolua_S) {
 return tolua_ShaderCom_open(tolua_S);
};
#endif

