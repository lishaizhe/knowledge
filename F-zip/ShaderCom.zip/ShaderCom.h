#ifndef __SHADERCOM_H__
#define __SHADERCOM_H__

#include "cocos2d.h"
using namespace cocos2d;

//this method just use shader to Rendering exist node
class ShaderCom
{
	ShaderCom();
public:
	static void init(CCNode* pNode, const char* vertex, const char* fragment);
	static void setOriginalShaderType(CCNode* pNode);
};

//this method is create a new node to call draw function to render shader shape

#endif