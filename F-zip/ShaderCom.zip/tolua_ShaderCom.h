#ifndef __TOLUA_SHADERCOM_H__
#define __TOLUA_SHADERCOM_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif
/* Exported function */
TOLUA_API int  tolua_ShaderCom_open (lua_State* tolua_S);

#endif //__LUA_CCB_H__
