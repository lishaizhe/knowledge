//
//  HttpUtils.cpp
//  mhsg
//
//  Created by 侯广大 on 14-11-7.
//
//

#include "Http.h"
#include "JsonParser.h"
#include <iostream>
#include <sstream>

NS_LEVER_BEGIN
USING_NS_CC;
using namespace cocos2d::network;
using namespace std;

LUA_FUNCTION Http::_chunk_handler = 0;
CURL* Http::_curl_handle = nullptr;
//std::function<void(msgpack::object& data)>& Http::_desFunc = NULL;

void Http::enableCookies(const std::string cookieFile) {
    network::HttpClient::getInstance()->enableCookies(cookieFile.c_str());
}

void Http::setTimeoutForConnect(int value) {
    network::HttpClient::getInstance()->setTimeoutForConnect(value);
}

/**
 * Get connect timeout
 * @return int
 */
int Http::getTimeoutForConnect() {
    return network::HttpClient::getInstance()->getTimeoutForConnect();
}


/**
 * Change the download timeout
 * @param value
 */
void Http::setTimeoutForRead(int value) {
    network::HttpClient::getInstance()->setTimeoutForRead(value);
}


/**
 * Get download timeout
 * @return int
 */
int Http::getTimeoutForRead() {
    return network::HttpClient::getInstance()->getTimeoutForRead();
}

void Http::get(LUA_FUNCTION handler, const string url)
{
    return get(handler, url,{});
}

void Http::get(LUA_FUNCTION handler, const string url, std::vector<std::string> headers) {
    request(handler, url, HttpRequest::Type::GET, "", headers, false);
}

void Http::getImmediate(LUA_FUNCTION handler, const string url)
{
    return getImmediate(handler, url,{});
}

void Http::getImmediate(LUA_FUNCTION handler, const string url, std::vector<std::string> headers) {
    request(handler, url, HttpRequest::Type::GET, "", headers, true);
}

void Http::post(LUA_FUNCTION handler, const string url, const string data)
{
    return post(handler, url, data, {});
}

void Http::post(LUA_FUNCTION handler, const string url, const string data, std::vector<std::string> headers) {
    request(handler, url, HttpRequest::Type::POST, data, headers, false);
}

void Http::postImmediate(LUA_FUNCTION handler, const string url, const string data)
{
    return postImmediate(handler, url, data, {});
}

void Http::postImmediate(LUA_FUNCTION handler, const string url, const string data, std::vector<std::string> headers) {
    request(handler, url, HttpRequest::Type::POST, data, headers, true);
}

void Http::request(LUA_FUNCTION handler, const string url, HttpRequest::Type type, const string data, std::vector<std::string> headers, bool isImmediate) {
    HttpRequest* request = new (std::nothrow) HttpRequest();
    if (!headers.empty()) {
        request->setHeaders(headers);
    }
    CCLOG(">><<< url: %s", url.c_str());
    request->setUrl(url.c_str());
    request->setRequestType(type);
    request->setResponseCallback(Http::onHttpRequestCompleted);
    char str[32]={0};
    sprintf(str,"%d",handler);
    request->setTag(str);
    if (!data.empty()) {
        request->setRequestData(data.c_str(), data.length());
    }
    signRequest(request);
    if (isImmediate) {
        HttpClient::getInstance()->sendImmediate(request);
    } else {
        HttpClient::getInstance()->send(request);
    }
}

void Http::_desMapFunc( msgpack::object& data ){
    msgpack::object_kv *pkv;
    msgpack::object_kv *pkv_end;
    msgpack::object pk, pv;
    
    if (data.via.map.size > 0)
    {
        pkv = data.via.map.ptr;
        pkv_end = data.via.map.ptr + data.via.map.size;
        do
        {
            pk = pkv->key;
            auto _pkData = pk.as< std::string >();
            CCLOG(" key: %s", _pkData.c_str());
            _desDataFunc(pkv->val);
            ++pkv;
        }while(pkv < pkv_end);
    }
};

void Http::_desArrayFunc(msgpack::object &data)
{
    if ( data.is_nil() )
        return;
    if (data.type != msgpack::type::ARRAY)
        return;
    auto _arrayData = data.via.array;
    for( int i = 0; i < _arrayData.size; ++i )
    {
        _desDataFunc( *(_arrayData.ptr+i) );
    }
}

void Http::_desDataFunc( msgpack::object& data)
{
    if ( data.is_nil() )
        return;
    if (data.type == msgpack::type::MAP)
    {
        _desMapFunc( data );
    }
    else if ( data.type == msgpack::type::ARRAY )
    {
        // 在这个地方还需要做递归
        _desArrayFunc( data );
    }
    else if ( data.type == msgpack::type::BOOLEAN )
    {
        auto _pvData = data.as< bool >();
        CCLOG(" value: %d", _pvData);
    }
    else if ( data.type == msgpack::type::POSITIVE_INTEGER )
    {
        auto _pvData = data.as< int >();
        CCLOG(" value: %d", _pvData);
    }
    else if ( data.type == msgpack::type::NEGATIVE_INTEGER )
    {
        auto _pvData = data.as< int >();
        CCLOG(" value: %d", _pvData);
    }
    else if ( data.type == msgpack::type::FLOAT )
    {
        auto _pvData = data.as< float >();
        CCLOG(" value: %f", _pvData);
    }
    else if ( data.type == msgpack::type::STR )
    {
        auto _pvData = data.as< std::string >();
        CCLOG(" value: %s", _pvData.c_str());
    }
}

void Http::onHttpRequestCompleted(HttpClient *sender, HttpResponse *response) {
    if (!response) {
        return;
    }
    
//    std::vector<char> *buffer1 = response->getResponseData();

    response->getHttpRequest()->release();
    decryptResponse(response);
    
    int statusCode = (int) response->getResponseCode();
    std::vector<char> *buffer = response->getResponseData();
    auto _buffLength = buffer->size();
    std::string responseData(buffer->begin(), buffer->end());
    std::vector<char> *headersBuffer = response->getResponseHeader();
    std::string headers(headersBuffer->begin(), headersBuffer->end());
    
    
//
//    std::map<std::string, std::string > _data;
//    _data.insert(std::pair<std::string, std::string>("sessionId", "6D131E6A4286F52131FC2FD9FB58EA8C"));
//    
//    std::map<std::string, int > _state;
//    _state.insert(std::pair<std::string, int>("state", 1));
//    
//    std::map< std::map<std::string, std::string>, std::map<std::string, int> > _action;
//    _action.insert(std::pair< std::map<std::string, std::string> , std::map<std::string, int> >( _data, _state) );
    
    // pack
//    msgpack::sbuffer _sbuffer1;
//    msgpack::pack(_sbuffer1, _action);
//    std::cout << _sbuffer1.data() << std::endl;
    
//    std::vector<int> _vec;
//    _vec.push_back(-123);
//    _vec.push_back(234);
//    _vec.push_back(-345);
//    _vec.push_back(456);
//    _vec.push_back(567);
    
//    char arr[4] = {'\0'};
//    arr[0] = 'a';
//    arr[1] = 'b';
//    arr[2] = 'c';
//    arr[3] = 'd';
//    
//    msgpack::sbuffer _sbuffer1;
//    msgpack::pack(_sbuffer1, arr);
//
//    msgpack::unpacked result2;
//    msgpack::unpack(result2, _sbuffer1.data(), _sbuffer1.size());
//    msgpack::object deserialized2 = result2.get();
    
    msgpack::unpacked _result;
    msgpack::unpack(_result, responseData.c_str(), responseData.size());
    msgpack::object _deserialized = _result.get();
    
    stringstream _stream;
    std::string _res = "";
    _stream<<_deserialized;
    while (!_stream.str().empty()) {
        std::string __zz = "";
        _stream>>__zz;
        if ( __zz == "" )
            break;
        _res += __zz;
        CCLOG(">>>xx22 %s", _res.c_str());
    }
    
    
//    std::cout << deserialized2 << std::endl;
//    std::vector< char* > _x = deserialized2.as< std::vector< char* > >();
//    for_each(_x.begin(), _x.end(), []( char* da ){
//        CCLOG(">>> data:::: %s " , da);
//    });
    
//    msgpack::unpacked result1;
//    msgpack::unpack(result1, responseData.c_str(), responseData.size());
//    msgpack::object deserialized = result1.get();
//    
//    if ( ! deserialized2.is_nil() )
//        _desDataFunc(deserialized2);
//    else
//    {
//        CCLOG("!!! warrning 网络返回错误");
//        return;
//    }
    
    
    
//    if ( deserialized.is_nil() )
//    {
//        if (deserialized.type == msgpack::type::MAP )
//        {
//            if (deserialized.via.map.size > 0)
//            {
//                pkv = deserialized.via.map.ptr;
//                pkv_end = deserialized.via.map.ptr + deserialized.via.map.size;
//                
//                do
//                {
//                    pk = pkv->key;
//                    pv = pkv->val;
//                    msgpack::type::object_type pkType = pk.type;
//                    msgpack::type::object_type pvType = pv.type;
//                    auto _pkData = pk.as< std::string >();
//                    auto _pvData = pv.as< std::map<char* , char*> >();
//                    //            CCLOG("%s", pv);
//                    ++pkv;
//                }while(pkv < pkv_end);
//            }
//
//        }
//    }
    
//    std::cout<< deserialized <<std::endl;
    
//    // 组装json
//    rapidjson::Document document;
//    rapidjson::Document::AllocatorType& allocator = document.GetAllocator();
//    rapidjson::Value contact( rapidjson::kArrayType );
    
    
    
//    msgpack::unpacked result;
//    msgpack::unpack(result, responseData.data(), responseData.size());
//    msgpack::object deserialized = result.get();
//    std::cout<< deserialized <<std::endl;
//
//    std::string _szxx = "";
//    stringstream _stream;
//    _stream<<deserialized;
//    _stream>>_szxx;
//    CCLOG("%s", _szxx.c_str());
//    
//    std::cout<< deserialized <<std::endl;
    
    
    
    //    deserialized.type
//    auto _pvData1 = deserialized.as< std::map<std::string , std::string> >();
    
    
    
//    std::map<std::string, std::string> _vecRString;
//    deserialized.convert(&_vecRString);
//
//    for_each(_vecRString.begin(), _vecRString.end(), [=]( std::string _data ){
//        CCLOG("%s", _data.c_str());
//    });
//    for
    
//    msgpack::object_kv *pkv;
//    msgpack::object_kv *pkv_end;
//    msgpack::object pk, pv;
//    if (deserialized.via.map.size > 0)
//    {
//        pkv = deserialized.via.map.ptr;
//        pkv_end = deserialized.via.map.ptr + deserialized.via.map.size;
//        
//        do
//        {
//            pk = pkv->key;
//            pv = pkv->val;
//            msgpack::type::object_type pkType = pk.type;
//            msgpack::type::object_type pvType = pv.type;
//            auto _pkData = pk.as< std::string >();
//            auto _pvData = pv.as< std::map<char* , char*> >();
////            CCLOG("%s", pv);
//            ++pkv;
//        }while(pkv < pkv_end);
//    }
    
    
//    msgpack::type::tuple<std::string> dst;
//    deserialized.convert(&dst);
//    CCLOG(">>> %s", dst.get<0>().c_str());
    
    
//    std::vector<std::string> _vecString;
//    _vecString.push_back("Hello");
//    _vecString.push_back("world");

//    std::map< std::string , std::string > _map;
//    _map.insert(std::pair<std::string, std::string>( "state", "action" ));
//    
//    // pack
//    msgpack::sbuffer _sbuffer;
//    msgpack::pack(_sbuffer, _map);
//    std::cout << _sbuffer.data() << std::endl;
//    
//    // unpack
//    msgpack::unpacked msg;
//    msgpack::unpack(&msg, _sbuffer.data(), _sbuffer.size());
//    msgpack::object obj = msg.get();
//    std::cout << obj << std::endl;
//
//    // convert
//    std::vector<std::string> _vecRString;
//    obj.convert(&_vecRString);
//    
//    // print
//    for(size_t i = 0; i < _vecRString.size(); ++i)
//    {
//        std::cout << _vecRString[i] << std::endl;
//    }
    
    
    
    CCLOG("HTTP request completed, url: %s \n  data: [ %s ]", response->getHttpRequest()->getUrl(), responseData.c_str());
    
//    if(headers.find("application/x-gzip-compressed") != headers.npos) //contains application/x-gzip-compressed
//    {
//        unsigned char* out;
//        ssize_t outSize=  cocos2d::ZipUtils::inflateMemory((unsigned char*)(&buffer->front()), buffer->size(), &out);
//        responseData.clear();
//        responseData.assign(out,out+outSize);
//        CC_SAFE_FREE(out);
//    }
//    const std::string& tmp = LuaValue::stringValue(responseData.c_str());
    
    LUA_FUNCTION handler = atoi(response->getHttpRequest()->getTag());
    
    if (!handler) {
        CCLOG("Handler for request %s is missing.", response->getHttpRequest()->getUrl());
        return;
    }
    
//    const std::string&  _x = LuaValue::stringValue(responseData).stringValue();
//    CCLOG(">>> length1: %lu", _x.length());
//    CCLOG(">>> length22: %lu", responseData.length());
    
    ScriptHandler::handle(handler, {
        LUAV_INT(statusCode),
        LUAV_STRING(_res.c_str()),
        LUAV_STRING(response->getErrorBuffer()),
        LUAV_STRING(headers.c_str())
    });
    ScriptHandler::releaseAsync(handler);
   
}

void Http::uploadFileAsyc(LUA_FUNCTION handler, const string url, const string localFilePath, std::vector<std::string> headers) {
    auto t = thread(bind((void(*)(LUA_FUNCTION, string, string, vector<string>))&Http::uploadFile, handler, url, localFilePath, headers));
    t.detach();
}

static size_t onWriteData(void *ptr, size_t size, size_t nmemb, void *userdata)
{
    string *data = (string*)userdata;
    data->append((char*)ptr, size * nmemb);
    return (size * nmemb);
}

void Http::uploadFile(LUA_FUNCTION h, const string url, const string localFilePath, vector<string> headers) {
    LUA_FUNCTION handler=h;
    long responseCode = -1;
    char errorBuffer[CURL_ERROR_SIZE] = { 0 };

    CURL *curl = curl_easy_init();
    curl_slist *_headers;
    
    std::string* responseData=new std::string();
    std::string* responseHeader=new std::string();
    
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errorBuffer);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, Http::getTimeoutForRead());
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, Http::getTimeoutForConnect());
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);   //避免超时时主线程被中断
    
    if(!headers.empty())
    {
        /* append custom headers one by one */
        for (std::vector<std::string>::iterator it = headers.begin(); it != headers.end(); ++it)
            _headers = curl_slist_append(_headers,it->c_str());
        /* set custom headers for curl */
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, _headers);
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, onWriteData);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, responseData);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, onWriteData);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, responseHeader);

//    curl_easy_setopt(curl, CURLOPT_POST, 1);
    struct curl_httppost* post = NULL;
    struct curl_httppost* last  = NULL;
    curl_formadd(&post, &last, CURLFORM_COPYNAME, "file", CURLFORM_FILE, localFilePath.c_str(), CURLFORM_END);
    curl_easy_setopt(curl, CURLOPT_HTTPPOST, post);
    
    CURLcode ret = curl_easy_perform(curl);
    CURLcode code = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &responseCode);
    
    CCLOG("ret: %d, code: %d", ret, code);
    CCLOG("responseData: %s, responseHeader: %s", responseData->c_str(), responseHeader->c_str());
    CCLOG("handler: %d, %d", handler, h);
    
    
    curl_slist_free_all(_headers);
    curl_easy_cleanup(curl);

    
    ScriptHandler::handleAsync(handler, {
        LUAV_INT(AS_UINT32(responseCode)),
        LUAV_STRING(responseData->c_str()),
        LUAV_STRING(errorBuffer),
        LUAV_STRING(responseHeader->c_str())
    });
    ScriptHandler::releaseAsync(handler);
    CC_SAFE_DELETE(responseData);
    CC_SAFE_DELETE(responseHeader);
}


// chunk 模式

void Http::setChunkHandler(LUA_FUNCTION handler)
{
    _chunk_handler = handler;
}

LUA_FUNCTION Http::getChunkHandler()
{
    return _chunk_handler;
}

void Http::http_chunk(LUA_FUNCTION h, const string url, const string localFilePath, vector<string> headers) {
    
    std::thread _thread([=](){
        //保存handler
        setChunkHandler(h);
        
        // 这个时候表示重连的情况下，即上次的网络还没有销毁
        if (_curl_handle != nullptr )
        {
            /* cleanup curl stuff */
            curl_easy_cleanup(_curl_handle);
            /* we're done with libcurl, so clean it up */
            curl_global_cleanup();
            /* reset curl-handler */
            _curl_handle = nullptr;
        }
        
        CURLcode res;
        
        curl_global_init(CURL_GLOBAL_ALL);
        
        /* init the curl session */
        _curl_handle = curl_easy_init();
        
        /* specify URL to get */
        curl_easy_setopt(_curl_handle, CURLOPT_URL, url.c_str());
        
        auto _cookie = UserDefault::getInstance()->getStringForKey("session");
        _cookie = "REIGNID="+_cookie;
        curl_easy_setopt(_curl_handle, CURLOPT_COOKIE, _cookie.c_str());
        
        /* some servers don't like requests that are made without a user-agent
         field, so we provide one */
        curl_easy_setopt(_curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");
        
        /* send all data to this function  */
        curl_easy_setopt(_curl_handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        
        /* get it! */
        res = curl_easy_perform(_curl_handle);
        
        /* check for errors */
        if(res != CURLE_OK) {
            fprintf(stderr, "chunk curl_easy_perform() failed: %s\n",
                    curl_easy_strerror(res));
        }
        else {
        }
        
        /* cleanup curl stuff */
        curl_easy_cleanup(_curl_handle);
        /* we're done with libcurl, so clean it up */
        curl_global_cleanup();
        _curl_handle = nullptr;
    });
    _thread.detach();
}

size_t Http::WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    size_t realsize = size * nmemb;
    
    //解析
    //空包
    if ( realsize <= 4 )
        return realsize;
    
    CCLOG(">>> realsize length: %zu", realsize);
    unsigned char* _contents = (unsigned char*)contents;
    
    //查看数据包的长度
    unsigned char bodylength[4] = {'\0'};
    memcpy(bodylength, _contents, 4);
    unsigned int * _nBodylength = (unsigned int*)bodylength;
    unsigned int _nBodylengthb = (*_nBodylength);
    unsigned int _nBodylengtha = ((_nBodylengthb & 0x000000FF) << 24) |
    ((_nBodylengthb & 0x0000FF00) << 8) |
    ((_nBodylengthb & 0x00FF0000) >> 8) |
    ((_nBodylengthb & 0xFF000000) >> 24) ;
    CCLOG(">>>length %d " , _nBodylengtha);
    
    // 判断消息长度不够
    if (realsize < _nBodylengtha) {
        return realsize;
    }
    
    unsigned char msglength[4] = {'\0'};
    memcpy(msglength, _contents+4, 4);
    int * _nMsglength = (int*)msglength;
    int _nMsglengthb = (*_nMsglength);
    int _nMsglengtha = ((_nMsglengthb & 0x000000FF) << 24) |
    ((_nMsglengthb & 0x0000FF00) << 8) |
    ((_nMsglengthb & 0x00FF0000) >> 8) |
    ((_nMsglengthb & 0xFF000000) >> 24) ;
    CCLOG(">>>length %d " , _nMsglengtha);
    
    unsigned char command[32] = {'\0'};
    memcpy(command, _contents+8, 32);
    CCLOG(">>>command %s " , command);
    
    unsigned char requestId[4] = {'\0'};
    memcpy(requestId, _contents+40, 4);
    int * _nRequestId = (int*)requestId;
    int _nRequestIdX = (*_nRequestId);
    int _nRequestIdY = ((_nRequestIdX & 0x000000FF) << 24) |
    ((_nRequestIdX & 0x0000FF00) << 8) |
    ((_nRequestIdX & 0x00FF0000) >> 8) |
    ((_nRequestIdX & 0xFF000000) >> 24) ;
    CCLOG(">>>requestId %d " , _nRequestIdY);
    
    
    std::string _szzMsg((char*)_contents+44, _nMsglengtha-36);
    CCLOG(">>>msg %s " , _szzMsg.c_str());
    
    
    // 向handler返回消息
    LUA_FUNCTION handler = getChunkHandler();
    ScriptHandler::handleAsync(handler, {
        LUAV_INT(AS_UINT32(200)),
        LUAV_STRING(_szzMsg.c_str()),
        LUAV_STRING(""),
        LUAV_STRING("")
    });
//    ScriptHandler::releaseAsync(handler);
    
    return realsize;
}



NS_LEVER_END