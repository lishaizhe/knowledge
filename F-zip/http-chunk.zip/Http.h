//
//  HttpUtils.h
//  mhsg
//
//  Created by 侯广大 on 14-11-7.
//
//

#ifndef __mhsg__HttpUtils__
#define __mhsg__HttpUtils__

#include "ScriptHandler.h"
#include "HttpClient.h"
#include "HttpRequest.h"
#include "HttpResponse.h"
#include <curl/curl.h>
#include "include/msgpack.hpp"

NS_LEVER_BEGIN
USING_NS_CC;
using namespace cocos2d::network;

class Http
{
public:
    
    /** Enable cookie support. **/
    static void enableCookies(const std::string cookieFile);
    
    
    /**
     * Change the connect timeout
     * @param value The desired timeout.
     */
    static void setTimeoutForConnect(int value);
    
    /**
     * Get connect timeout
     * @return int
     */
    static int getTimeoutForConnect();
    
    
    /**
     * Change the download timeout
     * @param value
     */
    static void setTimeoutForRead(int value);
    
    /**
     * Get download timeout
     * @return int
     */
    static int getTimeoutForRead();
    
    static void setAccessToken(const std::string token);
    
    static std::string getAccessToken(void);
    
    static std::string getSessionId();
    
    static void get(LUA_FUNCTION handler, const std::string url);

    static void get(LUA_FUNCTION handler, const std::string url, std::vector<std::string> headers);
    
    static void getImmediate(LUA_FUNCTION handler, const std::string url);

    static void getImmediate(LUA_FUNCTION handler, const std::string url, std::vector<std::string> headers);
    
    static void post(LUA_FUNCTION handler, const std::string url, const std::string data);

    static void post(LUA_FUNCTION handler, const std::string url, const std::string data, std::vector<std::string> headers);
    
    static void postImmediate(LUA_FUNCTION handler, const std::string url, const std::string data);
    
    static void postImmediate(LUA_FUNCTION handler, const std::string url, const std::string data, std::vector<std::string> headers);
    
    static void uploadFileAsyc(LUA_FUNCTION handler, const std::string url, const std::string localFilePath, std::vector<std::string> headers);
    
private:
    
    static void request(LUA_FUNCTION handler, const std::string url, HttpRequest::Type type, const std::string data, std::vector<std::string> headers, bool isImmediate);
    
    static void uploadFile(LUA_FUNCTION handler, const std::string url, const std::string localFilePath, std::vector<std::string> headers);
    
    /**
     * Http Response Callback
     * @param sender The request http client
     * @param response The response
     */
    static void onHttpRequestCompleted(HttpClient *sender, HttpResponse *response);
    
    
public:
    static void _desMapFunc( msgpack::object& data );
    
    static void _desArrayFunc( msgpack::object& data );
    
    static void _desDataFunc( msgpack::object& data );
    
    static void signRequest(HttpRequest *request);
    
    static void decryptResponse(HttpResponse *response);
    
    static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp);
    
    static void http_chunk(LUA_FUNCTION handler, const std::string url, const std::string localFilePath = "", std::vector<std::string> headers = {});
    
private:
    
    static std::string _accessToken;
    
    static std::string _sessionId;
    
    // 设置chunk模式下的句柄，愿意是在chunk模式下，perform处会卡主，不会继续进行，所以我们只能在回调方法中进行信息的处理
    static LUA_FUNCTION _chunk_handler;
    
    static void setChunkHandler( LUA_FUNCTION handler);
    
    static LUA_FUNCTION getChunkHandler();
    
    static CURL* _curl_handle;
    
    
    
};


NS_LEVER_END

#endif /* defined(__mhsg__HttpUtils__) */
