#!/bin/bash
str1="aaaaa"
str2="\n"
str3="aaaaa"
echo -e "$str1$str2$str3"