#!/bin/bash

#append_str=' \'

list_alldir()
{


    for file in $1/*
        do
            if [ -f $file ]; then

            all_name=`basename $file`
            dir_name=`dirname $file`
#这里判断一下是不是在不更新列表当中
                if [ ! -e /Users/liaoren88/Documents/cocos2d/hjsg/Resources/noChangeList/$all_name ]; then
					#判断一下大小

						./dwebp  ./imagesNew/$all_name -o ./imagesOld/$all_name

                fi
            
           fi
       done
}

if [ $# -gt 0 ]; then
    list_alldir "$1"
else
    list_alldir "."
fi
