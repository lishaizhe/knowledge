#!/bin/bash

var1=$(ls -1 $1 | wc -l | awk '{ print $1 }')
var2=$(ls -1 $2 | wc -l | awk '{ print $1 }')
echo "var1:$var1 var2:$var2"

function compareDir() {
		for file1 in $(ls $1); do
			#echo "$file1++"

			result=$(find $2 -name $file1)
			if [ -z "$result" ]; then
					echo "$file1++"
			fi

		done
}

if [ $var1 -gt $var2 ];then
	echo "$1!!!!!!"
	compareDir $1 $2
else
	echo "$2!!!!!!"
	compareDir $2 $1
fi



