#!/bin/bash

#append_str=' \'

list_alldir()
{


    for file in $1/*
        do
            if [ -f $file ]; then

            all_name=`basename $file`
            dir_name=`dirname $file`
#这里判断一下是不是在不更新列表当中
                if [ ! -e /Users/liaoren88/Documents/cocos2d/zsdl/Resources/noChangeList/$all_name ]; then
					#判断一下大小

                        ./cwebp -q 60 -m 6 -sharpness 1 -alpha_q 60 -alpha_filter best -f 60 -strong -af -sns 60 ./imagesOld/$all_name -o ./imagesNew/$all_name

                fi
            
           fi
       done
}

if [ $# -gt 0 ]; then
    list_alldir "$1"
else
    list_alldir "."
fi
