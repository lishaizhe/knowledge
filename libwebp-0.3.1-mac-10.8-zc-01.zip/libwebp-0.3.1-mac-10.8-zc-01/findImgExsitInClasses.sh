#!/bin/bash
pwdtest=$1"/findImg.txt"
find $1/* -type d >> ${pwdtest}

file_not_find1=""
space="\n"
for subdir in `cat ${pwdtest}`
do
{

        for file in $(ls ${subdir}); do
        	 echo "$file"
        	# grep $file /Users/liaoren88/Documents/cocos2d/zsdl/Classes -r | sed -n '$p'
        	result=$(grep /$file\" /Users/liaoren88/Documents/cocos2d/zsdl/Classes -r | sed -n '$p')
        	full_name=$subdir/$file
        	# echo "full_name-----$full_name"
        	if [ -z "$result" ]; then
        		 echo "$subdir/$file not find!!!"
        		file_not_find1=$full_name$space$file_not_find1
        	else
        		 echo "$subdir/$file find!!!"
        		 echo "$result"
        	fi
        done
        
}
done
echo -e "$subdir:+++++++++++++\n$file_not_find1"