#!/bin/bash
#cpdir



cpfrom=$1
cd $1
cd ..
cpto=$(pwd)"/resources-bak"
pwdtest=$(pwd)"/oldpwd.txt"
echo -e "$cpto\n$pwdtest"

if [ ! -d $cpto ]
then
{
 mkdir $cpto
 chmod 777 $cpto
 echo "创建主目录成功"
}
fi

cd $cpto

find $1/* -type d >> ${pwdtest}  #查找目录为文件夹的路径，写入到pwdtest文件中
chmod 777 ${pwdtest}                    #修改文件权限
sed -i "" "s#${cpfrom}#${cpto}#g" ${pwdtest}    #替换为新目录路径，这里注意必须用双引号
for subdir in `cat ${pwdtest}`
do
{
        mkdir ${subdir}
        echo "创建子目录----$subdir"
}
done
cd ..
echo "当前目录---$(pwd)"
for subdir1 in `cat ${pwdtest}`
do
{
        echo "源目录----$subdir1"
        subdir2=$(echo "$subdir1" | sed "s#${cpto}#${cpfrom}#g")
        echo "目标目录----$subdir2"


	    for file in $(ls ${subdir2})
	        do
				echo "文件转码----$file"
	            all_name=`basename $file`
	            dir_name=`dirname $file`
				#这里判断一下是不是在不更新列表当中
	                if [ ! -e /Users/liaoren88/Documents/cocos2d/zsdl/Resources/noChangeList/$all_name ]; then
							./cwebp -q 60 -m 6 -sharpness 1 -alpha_q 60 -alpha_filter best -f 60 -strong -af -sns 60 $subdir2/$all_name -o $subdir1/$all_name
	                fi
	     done
}
done

rm -rf ${pwdtest}                            