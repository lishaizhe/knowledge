#!/bin/bash

#append_str=' \'

list_alldir()
{


    for file in $1/*
        do
            if [ -f $file ]; then

            all_name=`basename $file`
            dir_name=`dirname $file`
#这里判断一下是不是在不更新列表当中

					#判断一下大小

						./cwebp -q 75  -m 4 -alpha_q 60 -af -sns 60 ./imagesOld/$all_name -o ./imagesNew/$all_name
					
                
            
           fi
       done
}

if [ $# -gt 0 ]; then
    list_alldir "$1"
else
    list_alldir "."
fi
