#!/bin/bash



var1=$(find $1 -type f -name "*.png" -o -name "*.jpg")
var2=$(find $2 -type f -name "*.png" -o -name "*.jpg")

var1_num=$(find $1 -type f -name "*.png" -o -name "*.jpg" | wc -l)
var2_num=$(find $2 -type f -name "*.png" -o -name "*.jpg" | wc -l)

echo "文件数量是:文件夹1-$var1_num 文件夹2-$var1_num"


		file_not_find1=""
		space="\n"
		for file in $var1; do
			file1=`basename $file`
			result=$(find $2 -type f -name $file1)
			num1=$(find $1 -type f -name $file1 | wc -l)
			num2=$(find $2 -type f -name $file1 | wc -l)
			# echo "hello1 $result $num1 $num2"
			if [ -n "$result" ] && [ $num1 -eq $num2 ]; then
				echo "$file1 has find!!" 
			else
				file_not_find1=$file$space$file_not_find1
			fi
		done
		fileDir1=`dirname $file`
		

		file_not_find2=""
		space="\n"
		for file in $var2; do
			file1=`basename $file`
			result=$(find $1 -type f -name $file1)
			num1=$(find $1 -type f -name $file1 | wc -l)
			num2=$(find $2 -type f -name $file1 | wc -l)
			# echo "hello2 $result $num1 $num2"
			if [ -n "$result" ] && [ $num1 -eq $num2 ]; then
				echo "$file1 has find!!" 
			else
				file_not_find2=$file$space$file_not_find2 
			fi
		done
		fileDir2=`dirname $file`
		echo -e "fileDir1:+++++++++++++\n$file_not_find1"
		echo -e "fileDir2:+++++++++++++\n$file_not_find2"


echo "文件数量是:文件夹1-$var1_num 文件夹2-$var1_num"



